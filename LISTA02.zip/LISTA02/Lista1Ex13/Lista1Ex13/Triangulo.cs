﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex13
{
    internal class Triangulo
    {
        private double v1;
        private double v2;
        private double v3;
        private string classificacao;

        public Triangulo()
        {
            this.v1 = 0;
            this.v2 = 0;
            this.v3 = 0;
        }
        public Triangulo(double v1, double v2, double v3)
        {
            this.v1 = v1;
            this.v2 = v2;
            this.v3 = v3;
        }

        public void setV1(double v1)
        {
            this.v1 = v1;
        }
        public void setV2(double v2)
        {
            this.v2 = v2;
        }
        public void setV3(double v3)
        {
            this.v3 = v3;
        }

        public double getV1()
        {
            return this.v1;
        }
        public double getV2()
        {
            return this.v2;
        }
        public double getV3()
        {
            return this.v3;
        }
        public string getClassificacao()
        {
            return this.classificacao;
        }
        public void calcular()
        {
            this.v1 = Math.Pow(this.v1, 2);
            this.v2 = Math.Pow(this.v2, 2);
            this.v3 = Math.Pow(this.v3, 2);

            if ((this.v1 + this.v2) == this.v3)
            {
                this.classificacao = "Formam um Triângulo Retângulo";
            }
            else
            {
                if ((this.v3 + this.v2) == this.v1)
                {
                    this.classificacao = "Formam um Triângulo Retângulo";
                }
                else
                {
                    if ((this.v1 + this.v3) == this.v2)
                    {
                        this.classificacao = "Formam um Triângulo Retângulo";
                    }
                    else
                    {
                        this.classificacao = "Não Formam um Triângulo Retângulo";
                    }
                }
            }
        }
    }
}
